Rails.application.routes.draw do
  root :to => 'homes#top'
  resources :books, except: [:new, :index]
  get 'books', to: 'books#indexnew', as: 'indexnew_books'
end
